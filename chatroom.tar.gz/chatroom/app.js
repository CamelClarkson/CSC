var express = require('express');
var app = express();
var port = 6000;
const http = require('http');
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/public/index.html')
});

app.get('/public/js/scripts.js', (req, res) => {
	res.sendFile(__dirname + '/public/js/scripts.js');
});

app.get('/public/css/styles.css', (req, res) => {
	res.sendFile(__dirname + '/public/css/styles.css');
});

io.on('connection', (socket) => {
    socket.on('init', (data) => {
        socket.username = data;
        console.log(data + ' has joined the chat.');
    });

    socket.on('msg', (data) => {
        console.log(data.username + ': ' + data.message);
        io.sockets.emit('msg', data);
    });

    socket.on('disconnect', () => {
        if (socket.users !== undefined) {
            console.log(socket.username + ' has disconnected.');
            io.sockets.emit('msg', {
                username: null,
                message: socket.username + ' has disconnected.',
                admin: true
            });
        }
    });
});

server.listen(port, '0.0.0.0', function() {
    console.log('Server on port: ' + port);
});
